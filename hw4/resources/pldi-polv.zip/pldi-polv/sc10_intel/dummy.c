#define LEN 32000
#define LEN2 256

int dummy(float a[LEN], float b[LEN], float c[LEN], float d[LEN], float e[LEN], float aa[LEN2][LEN2], float bb[LEN2][LEN2], float cc[LEN2][LEN2], float s){
	// --  called in each loop to make all computations appear required
	return 0;
}

void s216_dummy(float* a,float* b, float* c){}

