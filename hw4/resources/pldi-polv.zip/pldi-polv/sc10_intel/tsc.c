/*

Copyright (c) 2009 University of Illinois at Urbana-Champaign.  All rights reserved.



Developed by: Polaris Research Group

              University of Illinois at Urbana-Champaign

              http://polaris.cs.uiuc.edu



Permission is hereby granted, free of charge, to any person obtaining a copy

of this software and associated documentation files (the "Software"), to

deal with the Software without restriction, including without limitation the

rights to use, copy, modify, merge, publish, distribute, sublicense, and/or

sell copies of the Software, and to permit persons to whom the Software is

furnished to do so, subject to the following conditions:

  1. Redistributions of source code must retain the above copyright notice,

     this list of conditions and the following disclaimers.

  2. Redistributions in binary form must reproduce the above copyright

     notice, this list of conditions and the following disclaimers in the

     documentation and/or other materials provided with the distribution.

  3. Neither the names of Polaris Research Group, University of Illinois at

     Urbana-Champaign, nor the names of its contributors may be used to endorse

     or promote products derived from this Software without specific prior

     written permission.



THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR

IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,

FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE

CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER

LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING

FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS

WITH THE SOFTWARE.
*/

/*
 * This test is a transled version of TEST SUITE FOR VECTORIZING COMPILERS
 * from Fortran to C. The collection was written by:
 *  - David Callahan
 *  - Jack Dongarra
 *  - David Levine
 * The original benchmark can be downloaded from:
 *                    http://www.netlib.org/benchmark/vectors
 * The changes that we made to the original code:
 *  - We used f2c to convert the code to C.
 *
 *  - In the original code, each loop is executed with array lengths of
 * 10, 100, 1000. In this version length of arrays can be set by the 
 * macros LEN and LEN2 below for 1 and 2 dimensional arrays respectively.
 *
 *  - Each loop is executed multiple times to increase the running time.
 * This number can be changed by the macro ntimes below.
 *
 *  - The arrays start from 1 in Fortran and 0 in C. We have made all the
 * necessary changes in this regard.
 *
 *  - Fortran uses column-major and C uses row-major order. We have made 
 * all of the necessary changes in this regard
 *
 *  - We have expanded the collection with some of our loops. These loops
 * can be recognized by their function name; they start with an s and are
 * followed by a 4-digit number. There are some exceptions to 4-digit loops.
 * These loops are from the original collection:
 * Loops: s2710-s2712, s2101-s2102, s2111, s3110-s3113, s4112-s4117, s4121
 *
 *  - All the arrays are declared statically and globally and all of them are
 * 16-byte aligned.
 *
 * To compiler the colletion, the dummy.c file needs to be compiled separately
 * and the object file is linked to this file to compile it. An example of a
 * makefile is included in the package.
 * 
 *
 *  The output includes three columns:
 *	Loop:		The name of the loop
 *	Time(Sec): 	The time in seconds to run the loop
 *	Checksum:	The checksum calculated when the test has run
 *
 *
 * This version of the Benchmark is provided by:
 *  - Saeed Maleki   (maleki1@illinois.edu)  - University of Illinois at Urbana-Champaing
 *  - David Padua    (padua@illinois.edu)    - University of Illinois at Urbana-Champaing
 *  - Maria Garzaran (garzaran@illinois.edu) - University of Illinois at Urbana-Champaing
 */

#define LEN 32000
#define LEN2 256

#define ntimes 100000


#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <sys/param.h>
#include <sys/times.h>
#include <sys/types.h>
#include <time.h>
#include <malloc.h>
#include <string.h>
#include <assert.h>
#include <xmmintrin.h>
//#include <builtins.h>

#pragma auto_inline(off)

//float* __restrict__ array;
float array[LEN2*LEN2] __attribute__((aligned(16)));

float x[LEN] __attribute__((aligned(16)));
float temp;
int temp_int;

float a[LEN] __attribute__((aligned(16)));
float b[LEN] __attribute__((aligned(16)));
float c[LEN] __attribute__((aligned(16)));
float d[LEN] __attribute__((aligned(16)));
float e[LEN] __attribute__((aligned(16)));
float sum[LEN] __attribute__((aligned(16)));
float aa[LEN2][LEN2] __attribute__((aligned(16)));
float bb[LEN2][LEN2] __attribute__((aligned(16)));
float cc[LEN2][LEN2] __attribute__((aligned(16)));
float tt[LEN2][LEN2] __attribute__((aligned(16)));
int ip[LEN] __attribute__((aligned(16)));

int indx[LEN] __attribute__((aligned(16)));


float* __restrict__ xx;
float* yy;

int dummy(float[LEN], float[LEN], float[LEN], float[LEN], float[LEN], float[LEN2][LEN2], float[LEN2][LEN2], float[LEN2][LEN2], float);

int dummy_media(short[], char[], int);

int set1d(float arr[LEN], float value, int stride)
{
  int i;
  if (stride == -1) {
    for (int i = 0; i < LEN; i++) {
      arr[i] = 1. / (float) (i+1);
    }
  } else if (stride == -2) {
    for (int i = 0; i < LEN; i++) {
      arr[i] = 1. / (float) ((i+1) * (i+1));
    }
  } else {
    for (int i = 0; i < LEN; i += stride) {
      arr[i] = value;
    }
  }
  return 0;
}

int set1ds(int _n, float arr[LEN], float value, int stride)
{
  int i;
  if (stride == -1) {
    for (int i = 0; i < LEN; i++) {
      arr[i] = 1. / (float) (i+1);
    }
  } else if (stride == -2) {
    for (int i = 0; i < LEN; i++) {
      arr[i] = 1. / (float) ((i+1) * (i+1));
    }
  } else {
    for (int i = 0; i < LEN; i += stride) {
      arr[i] = value;
    }
  }
  return 0;
}

int set2d(float arr[LEN2][LEN2], float value, int stride)
{

//  -- initialize two-dimensional arraysft

  if (stride == -1) {
    for (int i = 0; i < LEN2; i++) {
      for (int j = 0; j < LEN2; j++) {
        arr[i][j] = 1. / (float) (i+1);
      }
    }
  } else if (stride == -2) {
    for (int i = 0; i < LEN2; i++) {
      for (int j = 0; j < LEN2; j++) {
        arr[i][j] = 1. / (float) ((i+1) * (i+1));
      }
    }
  } else {
    for (int i = 0; i < LEN2; i++) {
      for (int j = 0; j < LEN2; j += stride) {
        arr[i][j] = value;
      }
    }
  }
  return 0;
}

float sum1d(float arr[LEN]){
  float ret = 0.;
  for (int i = 0; i < LEN; i++)
    ret += arr[i];
  return ret;
}

float sum2d(float arr[LEN][LEN]){
  float ret = 0.;
  for (int i = 0; i < LEN2; i++)
    for (int j = 0; j < LEN2; j++)
      ret += arr[i][j];
  return ret;
}

int s471s(void)
{
// --  dummy subroutine call made in s471
  return 0;
}

float f(float a, float b){
  return a*b;
}

void check(int name){

  float suma = 0;
  float sumb = 0;
  float sumc = 0;
  float sumd = 0;
  float sume = 0;
  for (int i = 0; i < LEN; i++){
    suma += a[i];
    sumb += b[i];
    sumc += c[i];
    sumd += d[i];
    sume += e[i];
  }
  float sumaa = 0;
  float sumbb = 0;
  float sumcc = 0;
  for (int i = 0; i < LEN2; i++){
    for (int j = 0; j < LEN2; j++){
      sumaa += aa[i][j];
      sumbb += bb[i][j];
      sumcc += cc[i][j];

    }
  }
  float sumarray = 0;
  for (int i = 0; i < LEN2*LEN2; i++){
    sumarray += array[i];
  }

  if (name == 1) printf("%f \n",suma);
  if (name == 2) printf("%f \n",sumb);
  if (name == 3) printf("%f \n",sumc);
  if (name == 4) printf("%f \n",sumd);
  if (name == 5) printf("%f \n",sume);
  if (name == 11) printf("%f \n",sumaa);
  if (name == 22) printf("%f \n",sumbb);
  if (name == 33) printf("%f \n",sumcc);
  if (name == 0) printf("%f \n",sumarray);
  if (name == 12) printf("%f \n",suma+sumb);
  if (name == 25) printf("%f \n",sumb+sume);
  if (name == 13) printf("%f \n",suma+sumc);
  if (name == 123) printf("%f \n",suma+sumb+sumc);
  if (name == 1122) printf("%f \n",sumaa+sumbb);
  if (name == 112233) printf("%f \n",sumaa+sumbb+sumcc);
  if (name == 111) printf("%f \n",sumaa+suma);
  if (name == -1) printf("%f \n",temp);
  if (name == -12) printf("%f \n",temp+sumb);

}

int init()
{
  float any=0.;
  float zero=0.;
  float half=.5;
  float one=1.;
  float two=2.;
  float small = .000001;
  int unit =1;
  int frac=-1;
  int frac2=-2;

  set1d(a, one,unit);
  set1d(b, any,frac2);
  set1d(c, any,frac2);
  set1d(d, any,frac2);
  set1d(e, any,frac2);
  set2d(aa, one,unit);
  set2d(bb, one,unit);
  set2d(cc, one,unit);

  return 0;
}

void print_array(float* a, int size){
  for (int i = 0; i < size; i++)
    printf("%.5f ", (float)a[i]);
  printf("\n--------------\n");
}

int s000()
{

  clock_t start_t, end_t, clock_dif; double clock_dif_sec;

  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN; i++) {
      c[i] = a[i] * b[i];
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S000\t %.2f \t\t", clock_dif_sec);;
  check(3);
  return 0;
}

int s000_1()
{

  clock_t start_t, end_t, clock_dif; double clock_dif_sec;

  init();
  start_t = clock();

  __m128 rA,rB,rC;
  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN; i+=4) {
      rA = _mm_load_ps(&a[i]);
      rB = _mm_load_ps(&b[i]);
      rC = _mm_mul_ps(rA,rB);
      _mm_store_ps(&c[i],rC);
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S000_1\t %.2f \t\t", clock_dif_sec);;
  check(3);
  return 0;
}

int s111(float** M1, float** M2, float** M3)
{

  clock_t start_t, end_t, clock_dif; double clock_dif_sec;

  init();
  start_t = clock();

  for (int nl = 0; nl < ntimes/(10*LEN2); nl++) {
    for (int i = 0; i < LEN2; i++) {
      for (int j = 0; j < LEN2; j++) {
        M3[i][j] = (float)0.;
#ifndef altivec
        __assume_aligned(M3[i],16);
        __assume_aligned(M2,16);
        __assume_aligned(M1[i],16);
#endif
        for (int k = 0; k < LEN2; k++) {
          M3[i][j] += M1[i][k]*M2[k][j];
        }
      }
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S111\t %.2f \t\t", clock_dif_sec);
  float ttt = (float)0.;
  for (int i = 0; i < LEN2; i++)
    for (int j = 0; j < LEN2; j++)
      ttt += M3[i][j];
  temp = ttt;
  check(-1);
  return 0;
}

int s111_1(float** __restrict__ M1, float** __restrict__ M2, float** __restrict__ M3)
{

  clock_t start_t, end_t, clock_dif; double clock_dif_sec;

  init();
  start_t = clock();

  for (int nl = 0; nl < ntimes/(10*LEN2); nl++) {
    for (int i = 0; i < LEN2; i++) {
      for (int j = 0; j < LEN2; j++) {
        M3[i][j] = (float)0.;
#ifndef altivec
        __assume_aligned(M3[i],16);
        __assume_aligned(M2,16);
        __assume_aligned(M1[i],16);
#endif
        for (int k = 0; k < LEN2; k++) {
          M3[i][j] += M1[i][k]*M2[k][j];
        }
      }
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S111_1\t %.2f \t\t", clock_dif_sec);
  float ttt = (float)0.;
  for (int i = 0; i < LEN2; i++)
    for (int j = 0; j < LEN2; j++)
      ttt += M3[i][j];
  temp = ttt;
  check(-1);
  return 0;
}

int s111_2(float** __restrict__ M1, float** __restrict__ M2, float** __restrict__ M3)
{

  clock_t start_t, end_t, clock_dif; double clock_dif_sec;

  init();
  start_t = clock();

  for (int nl = 0; nl < ntimes/(10*LEN2); nl++) {
    for (int i = 0; i < LEN2; i++) {
      for (int j = 0; j < LEN2; j++) {
//        M3[i][j] = (float)0.;
        float t_M3 = (float) 0.;
#ifndef altivec
        __assume_aligned(M3[i],16);
        __assume_aligned(M2,16);
        __assume_aligned(M1[i],16);
        #pragma vector always
#endif
        for (int k = 0; k < LEN2; k++) {
          t_M3 += M1[i][k]*M2[k][j];
        }
        M3[i][j] = t_M3;
      }
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S111_2\t %.2f \t\t", clock_dif_sec);
  float ttt = (float)0.;
  for (int i = 0; i < LEN2; i++)
    for (int j = 0; j < LEN2; j++)
      ttt += M3[i][j];
  temp = ttt;
  check(-1);
  return 0;
}

int s111_3(float** __restrict__ M1, float** __restrict__ M2, float** __restrict__ M3)
{

  clock_t start_t, end_t, clock_dif; double clock_dif_sec;

  init();
  start_t = clock();

  for (int nl = 0; nl < ntimes/(10*LEN2); nl++) {
    for (int i = 0; i < LEN2; i++)
      for (int j = 0; j < LEN2; j++)
        M3[i][j] = (float)0.;
    for (int i = 0; i < LEN2; i++) {
      for (int k = 0; k < LEN2; k++) {
#ifndef altivec
        __assume_aligned(M1[i],16);
        __assume_aligned(M3[i],16);
        __assume_aligned(M2[k],16);
#endif
        for (int j = 0; j < LEN2; j++) {
          M3[i][j] += M1[i][k]*M2[k][j];
        }
      }
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S111_3\t %.2f \t\t", clock_dif_sec);
  float ttt = (float)0.;
  for (int i = 0; i < LEN2; i++)
    for (int j = 0; j < LEN2; j++)
      ttt += M3[i][j];
  temp = ttt;
  check(-1);
  return 0;
}

void s111_4s(float m1, float* __restrict__ m2, float* __restrict__ m3){
#ifdef altivec
  __alignx(16, m3);
  __alignx(16, m2);
#else
  __assume_aligned(m3, 16);
  __assume_aligned(m2, 16);
#endif
  for (int j = 0; j < LEN2; j++) {
    m3[j] += m1*m2[j];
  }
}

int s111_4(float** __restrict__ M1, float** __restrict__ M2, float** __restrict__ M3)
{

  clock_t start_t, end_t, clock_dif; double clock_dif_sec;

  init();
  start_t = clock();

#ifdef altivec
#pragma disjoint(**M3, **M1, **M2)
#endif
  for (int nl = 0; nl < ntimes/(10*LEN2); nl++) {
    for (int i = 0; i < LEN2; i++)
      for (int j = 0; j < LEN2; j++)
        M3[i][j] = (float)0.;
    for (int i = 0; i < LEN2; i++) {
      for (int k = 0; k < LEN2; k++) {
        s111_4s(M1[i][k], M2[k], M3[i]);
      }
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S111_4\t %.2f \t\t", clock_dif_sec);
  float ttt = (float)0.;
  for (int i = 0; i < LEN2; i++)
    for (int j = 0; j < LEN2; j++)
      ttt += M3[i][j];
  temp = ttt;
  check(-1);
  return 0;
}

#define RESTRICT
//#define RESTRICT __restrict__

int s1111(float* RESTRICT A, float* RESTRICT B, float* RESTRICT C,             
          float* RESTRICT D, float* RESTRICT E)
{

  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < ntimes; nl++) {
#ifdef altivec
    __alignx(16, A);
    __alignx(16, B);
    __alignx(16, C);
#else
   __assume_aligned(A,16);
   __assume_aligned(B,16);
   __assume_aligned(C,16);
#endif
    for (int i = 0; i < LEN2*100; i++) {
      A[i] = B[i] + C[i] + D[i] + E[i];
    }
    dummy(A,B,C,D,E, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S1111\t %.2f \t\t", clock_dif_sec);
  float ttt = (float)0.;
  for (int i = 0; i < LEN2; i++)
    ttt += A[i];
  temp = ttt;
  check(-1);
  return 0;
}



int s112()
{

  clock_t start_t, end_t, clock_dif; double clock_dif_sec;

  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN; i++) {
      a[i] = b[i] + (float)1.0;
      c[i] = b[i] + (float)2.0;
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S112\t %.2f \t\t", clock_dif_sec);;
  check(13);
  return 0;
}

int s112_1()
{
  clock_t start_t, end_t, clock_dif; double clock_dif_sec;

  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN; i++) {
      a[i] = b[i] + (float)1.0;
    }
    for (int i = 0; i < LEN; i++) {
      c[i] = b[i] + (float)2.0;
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S112_1\t %.2f \t\t", clock_dif_sec);;
  check(13);
  return 0;
}

int s112_2()
{

  clock_t start_t, end_t, clock_dif; double clock_dif_sec;

  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN; i+=4) {
      for (int j = i; j < i+4; j++){
        a[j] = b[j] + (float)1.0;
        c[j] = b[j] + (float)2.0;
      }
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S112_2\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s113()
{

  clock_t start_t, end_t, clock_dif; double clock_dif_sec;

  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN; i++) {
      a[i] = b[i] + c[i];
      d[i] = a[i] + (float) 1.0;
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S113\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s113_1()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN; i++) {
      a[i] = b[i] + c[i];
    }
    for (int i = 0; i < LEN; i++) {
      d[i] = a[i] + (float) 1.0;
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S113\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s114()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN; i++) {
      a[i] = b[i] + c[i];
      d[i] = a[i+1] + (float) 1.0;
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S114\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s114_1()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN; i++) {
      d[i] = a[i+1] + (float) 1.0;
      a[i] = b[i] + c[i];
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S114_1\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s214()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < ntimes/10; nl++) {
    for (int i = 1; i < LEN; i++) {
      a[i] = d[i-1] + (float)sqrt(c[i]);
      d[i] = b[i] + (float)sqrt(e[i]);
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S214\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s214_1()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < ntimes/10; nl++) {
    for (int i = 1; i < LEN; i++) {
      d[i] = b[i] + (float)sqrt(e[i]);
      a[i] = d[i-1] + (float)sqrt(c[i]);
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S214_1\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s115()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN-1; i++) {
      b[i] = a[i] + (float)1.0;
      a[i+1] = b[i] + (float) 2.0;
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S115\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s116()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 1; i < LEN; i++) {
      a[i] = b[i] + c[i];
      d[i] = a[i] + e[i-1];
      e[i] = d[i] + c[i];
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S116\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s116_1()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 1; i < LEN; i++) {
      a[i] = b[i] + c[i];
    }
    for (int i = 1; i < LEN; i++) {
      d[i] = a[i] + e[i-1];
      e[i] = d[i] + c[i];
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S116_1\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}


void s216_dummy(float* a,float* b, float* c);

int s216()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < ntimes/10; nl++) {
    for (int i = 0; i < LEN; i++) {
      a[i] = (float)sqrt(b[i]) + (float)sqrt(c[i]);
      s216_dummy(a,b,c);
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S216\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s216_1()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < ntimes/10; nl++) {
    for (int i = 0; i < LEN; i++) {
      a[i] = (float)sqrt(b[i]) + (float)sqrt(c[i]);
    }
    for (int i = 0; i < LEN; i++) {
      s216_dummy(a,b,c);
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S216_1\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s117()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN-1; i++) {
      a[i] = a[i+1] + b[i];
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S117\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s118()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 1; i < LEN; i++) {
      a[i] = a[i-1] + b[i];
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S118\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

void s119s(){
  for (int i = 4; i < LEN; i++)
  a[i] = a[i-4] + b[i];
}

int s119()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    s119s();
//    for (int i = 4; i < LEN; i++) {
//      a[i] = a[i-4] + b[i];
//    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S119\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s121()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN2-1; i++){
      for (int j = 0; j < LEN2; j++)
        aa[i+1][j] = aa[i][j] + (float)1.0;
      
      dummy(a, b, c, d, e, aa, bb, cc, 0.);
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S121\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s122()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 200*ntimes; nl++) {
    for (int i = 0; i < LEN2-1; i++)
      a[ip[i]] = a[ip[i]] * (float)2.0;
      
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S122\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s123()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 200*ntimes; nl++) {
    for (int i = 0; i < LEN2-1; i++){
      ip[i] = i;
      a[ip[i]] = a[ip[i]] * (float)2.0;
    }      
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S123\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s124(int k)
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN-k; i++)
      a[i] = a[i+k] + b[i];
      
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S124\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s124_1(int k)
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    if (k >= 0)
      for (int i = 0; i < LEN-k; i++)
        a[i] = a[i+k] + b[i];
    if (k < 0)
      for (int i = 0; i < LEN-k; i++)
        a[i] = a[i+k] + b[i];
      
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S124_1\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s124_2(int k)
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    if (k >= 0)
      #pragma ivdep
      for (int i = 0; i < LEN-k; i++)
        a[i] = a[i+k] + b[i];
    if (k < 0)
      for (int i = 0; i < LEN-k; i++)
        a[i] = a[i+k] + b[i];
      
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S124_2\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s125()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 1; i < LEN; i++){
      a[i] = b[i] + (float)2.0;
      c[i] = c[i-1] + a[i];
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S125\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s125_1()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 1; i < LEN; i++)
      a[i] = b[i] + (float)2.0;
    for (int i = 1; i < LEN; i++)
      c[i] = c[i-1] + a[i];
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S125_1\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s126()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN-1; i++){
      a[i] = b[i] + c[i];
      d[i] = (a[i] + a[i+1])*(float)0.5;
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S126\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s126_1()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN-1; i++){
      e[i] = a[i+1];
      a[i] = b[i] + c[i];
      d[i] = (a[i] + e[i])*(float)0.5;
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S126_1\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s126_2()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    __m128 rA1, rA2, rB, rC, rD;
    __m128 r5 = _mm_set1_ps((float)0.5);
    for (int i = 0; i < LEN-4; i+=4){
      rA2 = _mm_loadu_ps(&a[i+1]);
      rB  = _mm_load_ps(&b[i]);
      rC  = _mm_load_ps(&c[i]);
      rA1 = _mm_add_ps(rB,rC);
      rD  = _mm_mul_ps(_mm_add_ps(rA1,rA2),r5);
      _mm_store_ps(&a[i], rA1);
      _mm_store_ps(&d[i], rD);
    }
    for (int i = LEN-4; i < LEN-1; i++){
      a[i] = b[i] + c[i];
      d[i] = (a[i] + a[i+1])*(float)0.5;
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S126_2\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s127()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN; i++){
      a[i] = a[i] + a[0];
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S127\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s127_1()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    a[0] = a[0] + a[0];
    for (int i = 1; i < LEN; i++){
      a[i] = a[i] + a[0];
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S127_1\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s128()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 20*ntimes/LEN2; nl++) {
    for (int j = 0; j < LEN2-1; j++)
      for (int i = 1; i < LEN2; i++)
        aa[i][j] = aa[i-1][j+1] + (float)1.0;
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S128\t %.2f \t\t", clock_dif_sec);;
  check(11);
  return 0;
}

int s228()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 50*ntimes/LEN2; nl++) {
    for (int j = 1; j < LEN2; j++)
      for (int i = j; i < LEN2; i++)
        aa[i][j] = aa[i-1][j] + (float)1.0;
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S228\t %.2f \t\t", clock_dif_sec);;
  check(11);
  return 0;
}

int s228_1()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 50*ntimes/LEN2; nl++) {
    for (int i = 1; i < LEN2; i++)
      for (int j = 1; j < i+1; j++)
        aa[i][j] = aa[i-1][j] + (float)1.0;
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S228_1\t %.2f \t\t", clock_dif_sec);;
  check(11);
  return 0;
}

int s129()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 20*ntimes/LEN2; nl++) {
    for (int j = 0; j < LEN2; j++)
      for (int i = 1; i < LEN2; i++)
        aa[i][j] = aa[i-1][j] + b[i];
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S128\t %.2f \t\t", clock_dif_sec);;
  check(11);
  return 0;
}

int s131()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  float sum;
  for (int nl = 0; nl < 2*ntimes; nl++) {
    sum = (float)0.0;
    for (int i = 0; i < LEN; i++){
      sum += a[i];
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S131\t %.2f \t\t", clock_dif_sec);
  temp = sum;
  check(-1);
  return 0;
}

int s132()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  float x;
  int index;
  for (int nl = 0; nl < 2*ntimes; nl++) {
    x = a[0];
    index = 0;
    for (int i = 0; i < LEN; i++){
      if (a[i] > x){
        x = a[i];
        index = i;
      }
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S132\t %.2f \t\t", clock_dif_sec);
  temp = x+index;
  check(-1);
  return 0;
}

int s133()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  float s;
  for (int nl = 0; nl < 2*ntimes; nl++) {
    s = (float)0.0;
    for (int i = 0; i < LEN; i++){
      s += (float)2.0;
      a[i] = s * b[i];
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S133\t %.2f \t\t", clock_dif_sec);
  check(1);
  return 0;
}

int s133_1()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  float s;
  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN; i++){
      a[i] = (float)2.0*(i+1)*b[i];
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S133_1\t %.2f \t\t", clock_dif_sec);
  check(1);
  return 0;
}

int s134()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    float* __restrict__ A = a;
    float* __restrict__ B = b;
    float* __restrict__ C = c;
    __assume_aligned(A, 16);
    __assume_aligned(B, 16);
    __assume_aligned(C, 16);
    for (int i = 0; i < LEN; i++){
      *A = *B + *C;
      A++; B++; C++;
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S134\t %.2f \t\t", clock_dif_sec);
  check(1);
  return 0;
}

int s134_1()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    float* __restrict__ A = a;
    float* __restrict__ B = b;
    float* __restrict__ C = c;
    __assume_aligned(A, 16);
    __assume_aligned(B, 16);
    __assume_aligned(C, 16);
    for (int i = 0; i < LEN; i++){
      A[i] = B[i] + C[i];
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S134_1\t %.2f \t\t", clock_dif_sec);
  check(1);
  return 0;
}

typedef struct{int x,y,z;} point;

point pt[LEN];

int s135()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;

  for (int i = 0; i < LEN; i++){
    pt[i].x = 1;
    pt[i].y = 2;
    pt[i].z = 3;
  }
  int scale = 4;
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN; i++){
      pt[i].y *= scale;
    }
    dummy((float*)&(pt[0].y), b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S135\t %.2f \t\t", clock_dif_sec);
  temp = (float)0.0;
  for (int i = 0; i < LEN; i++)
    temp += (float)pt[i].y;
  check(-1);
  return 0;
}

int ptx[LEN];
int pty[LEN];
int ptz[LEN];

int s135_1()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;

  for (int i = 0; i < LEN; i++){
    ptx[i] = 1;
    pty[i] = 2;
    ptz[i] = 3;
  }
  int scale = 4;
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    for (int i = 0; i < LEN; i++){
      pty[i] *= scale;
    }
    dummy((float*)&(pt[0].y), b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S135_1\t %.2f \t\t", clock_dif_sec);
  temp = (float)0.0;
  for (int i = 0; i < LEN; i++)
    temp += (float)pty[i];
  check(-1);
  return 0;
}

int s136()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 80*ntimes/LEN2; nl++) {
    for (int i = 0; i < LEN2; i++){
      float sum = (float)0.0;
      for (int j = 0; j < LEN2; j++){
        sum += aa[j][i];
      }
      e[i] = sum;
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S136\t %.2f \t\t", clock_dif_sec);;
  check(5);
  return 0;
}

int s136_1()
{

  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 80*ntimes/LEN2; nl++) {
    for (int i = 0; i < LEN2; i++){
      sum[i] = (float)0.0;
      for (int j = 0; j < LEN2; j++){
        sum[i] += aa[j][i];
      }
      e[i] = sum[i];
    }
    dummy(a, b, c, d, sum, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S136_1\t %.2f \t\t", clock_dif_sec);;
  check(5);
  return 0;
}

int s136_2()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 80*ntimes/LEN2; nl++) {
    for (int i = 0; i < LEN2; i++)
      e[i] = (float)0.0;
    for (int j = 0; j < LEN2; j++){
      for (int i = 0; i < LEN2; i++){
        e[i] += aa[j][i];
      }
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S136_2\t %.2f \t\t", clock_dif_sec);;
  check(5);
  return 0;
}

int s137(float* __restrict__ A, float* __restrict__ B, float* __restrict__ C, 
         float* __restrict__ D)
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    __assume_aligned(A, 16);
    __assume_aligned(B, 16);
    __assume_aligned(C, 16);
    __assume_aligned(D, 16);
    for (int i = 0; i < LEN; i++){
      if (C[i] > (float) -1.0)
        A[i] = A[i] * B[i] + D[i];
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S137\t %.2f \t\t", clock_dif_sec);;
  check(2);
  return 0;
}

int s137_1(float* __restrict__ A, float* __restrict__ B, float* __restrict__ C, 
         float* __restrict__ D)
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < 2*ntimes; nl++) {
    __assume_aligned(A, 16);
    __assume_aligned(B, 16);
    __assume_aligned(C, 16);
    __assume_aligned(D, 16);
    #pragma vector always
    for (int i = 0; i < LEN; i++){
      if (C[i] > (float) -1.0)
        A[i] = A[i] * B[i] + D[i];
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S137_1\t %.2f \t\t", clock_dif_sec);;
  check(2);
  return 0;
}

int s138()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  for (int i = 0; i < LEN; i++){
    if (i % 1000 == 0) 
      c[i] = (float) 1.0;
    else
      c[i] = (float) 0.0;
  }
  start_t = clock();

  for (int nl = 0; nl < ntimes/5; nl++) {
    for (int i = 0; i < LEN; i++){
      if (c[i] == (float)0.0)
        a[i] = d[i]*(float)2.0;
      else
        a[i] = c[i]/e[i]/b[i]/d[i]/a[i]+d[i]*(float)2.0;
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S138\t %.2f \t\t", clock_dif_sec);;
  check(2);
  return 0;
}

int s138_1()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  for (int i = 0; i < LEN; i++){
    if (i % 1000 == 0) 
      c[i] = (float) 1.0;
    else
      c[i] = (float) 0.0;
  }
  start_t = clock();

  for (int nl = 0; nl < ntimes/5; nl++) {
    for (int i = 0; i < LEN; i++)
      a[i] = d[i]*(float)2.0;
    #pragma novector
    for (int i = 0; i < LEN; i++){
      if (c[i] != (float)0.0)
        a[i] += c[i]/e[i]/b[i]/d[i]/a[i];
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S138_1\t %.2f \t\t", clock_dif_sec);;
  check(2);
  return 0;
}

int s139()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < ntimes/5; nl++) {
    float t;
    for (int i = 0; i < LEN; i++){
      t = a[i];
      a[i] = b[i] + (float) 1.0;
      b[i] = t;
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S139\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s139_1()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  for (int nl = 0; nl < ntimes/5; nl++) {
    float t[LEN] __attribute__ ((aligned(16)));
    for (int i = 0; i < LEN; i++){
      t[i] = a[i];
      a[i] = b[i] + (float) 1.0;
      b[i] = t[i];
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S139_1\t %.2f \t\t", clock_dif_sec);;
  check(1);
  return 0;
}

int s141()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  float max;
  int loc;
  for (int nl = 0; nl < ntimes/5; nl++) {
    max = a[0];
    loc = 0;
    for (int i = 0; i < LEN; i++){
      if (max < a[i]){
        max = a[i];
        loc = i;
      }
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S141\t %.2f \t\t", clock_dif_sec);;
  temp = max + loc;
  check(-1);
  return 0;
}

int s141_1()
{




  clock_t start_t, end_t, clock_dif; double clock_dif_sec;


  init();
  start_t = clock();

  float MAX;
  int LOC;
  for (int nl = 0; nl < ntimes/5; nl++) {
    float max[32];
    int loc[32];

    for (int i = 0; i < 32; i++){
      max[i] = a[i];
      loc[i] = i;
    }

    for (int i = 0; i < LEN; i+=32){
      for (int j = 0, k = i; k < i+32; k++, j++){
        if (max[j] < a[i]){
          max[j] = a[i];
          loc[j] = i;
        }
      }
    }
    MAX = max[0];
    LOC = 0;
    for (int i = 0; i < 32; i++){
      if (MAX < max[i]){
        MAX = max[i];
        LOC = loc[i];
      }
    }
    dummy(a, b, c, d, e, aa, bb, cc, 0.);
  }
  end_t = clock(); clock_dif = end_t - start_t;
  clock_dif_sec = (double) (clock_dif/1000000.0);
  printf("S141_1\t %.2f \t\t", clock_dif_sec);;
  temp = MAX+LOC;
  check(-1);
  return 0;
}

// %1.1

void set(float* s1, float* s2){
  printf("\n");
  for (int i = 0; i < LEN; i = i+5){
    ip[i]  = (i+4);
    ip[i+1] = (i+2);
    ip[i+2] = (i);
    ip[i+3] = (i+3);
    ip[i+4] = (i+1);
  }

  set1d(a, 1.,1);
  set1d(b, 1.,1);
  set1d(c, 1.,1);
  set1d(d, 1.,1);
  set1d(e, 1.,1);
  set2d(aa, 0.,-1);
  set2d(bb, 0.,-1);
  set2d(cc, 0.,-1);

  for (int i = 0; i < LEN; i++){
    indx[i] = (i+1) % 4+1;
  }
  *s1 = 1.0;
  *s2 = 2.0;

}

int main(){
  int n1 = 1;
  int n3 = 1;
  float s1,s2;
  set(&s1, &s2);
  printf("Loop \t Time(Sec) \t Checksum \n");

  float** M1 = (float**) memalign(16, LEN2*sizeof(float*));
  float** M2 = (float**) memalign(16, LEN2*sizeof(float*));
  float** M3 = (float**) memalign(16, LEN2*sizeof(float*));
  for (int i = 0; i < LEN2; i++){
    M1[i] = (float*) memalign(16, LEN2*sizeof(float));
    M2[i] = (float*) memalign(16, LEN2*sizeof(float));
    M3[i] = (float*) memalign(16, LEN2*sizeof(float));
  }

  for (int i = 0; i < LEN2; i++){
    for (int j = 0; j < LEN2; j++){
      M1[i][j] = (float)(i+j)/(float)LEN2;
      M2[i][j] = (float)(i+j+1)/(float)LEN2;
      M3[i][j] = (float)(i+j+2)/(float)LEN2;
    }
  }

  s000();
  s000_1();
  s111(M1,M2,M3);
  s111_1(M1,M2,M3);
  s111_2(M1,M2,M3);
  s111_3(M1,M2,M3);
  s111_4(M1,M2,M3);
  s1111(a,b,c,d,e);
  s112();
  s112_1();
  s112_2();
  s113();
  s113_1();
  s114();
  s114_1();
  s214();
  s214_1();
  s115();
  s116();
  s116_1();
  s216();
  s216_1();
  s117();
  s118();
  s119();
  s121();
  s122();
  s123();
  s124(1);
  s124_1(1);
  s124_2(1);
  s125();
  s125_1();
  s126();
  s126_1();
  s126_2();
  s127();
  s127_1();
  s128();
  s228();
  s228_1();
  s129();
  s131();
  s132();
  s133();
  s133_1();
  s134();
  s134_1();
  s135();
  s135_1();
  s136();
  s136_1();
  s136_2();
  s137(a, b, c, d);
  s137_1(a, b, c, d);
  s138();
  s138_1();
  s139();
  s139_1();
  s141();
  s141_1();
  return 0;
}

