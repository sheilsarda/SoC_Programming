#define LEN2 256
#define LEN 32000

void ttt(float** __restrict__ A, float** __restrict__ B, float** __restrict__ C){
  int i,j,k;
  for (i = 0; i < 1024; i++)
    for (k = 0; k < 1024; k++)
      for (j = 0; j < 1024; j++){
        A[i][j] += B[i][k] * C[k][j];
    }
}


int s111_3(float** __restrict__ M1, float** __restrict__ M2, float** __restrict__ M3)
{

                for (int i = 0; i < LEN2; i++) {
                        for (int k = 0; k < LEN2; k++) {
                                for (int j = 0; j < LEN2; j++) {
                                        M3[i][j] += M1[i][k]*M2[k][j];
                                }
                        }
                }
        return 0;
}


int s111_4(float M1[LEN2][LEN2], float M2[LEN2][LEN2], float M3[LEN2][LEN2])
{


                for (int i = 0; i < LEN2; i++) {
                        for (int j = 0; j < LEN2; j++) {
				float temp = (float)0.;
				#pragma vector always
                        	for (int k = 0; k < LEN2; k++) {
                                        temp += M1[i][k]*M2[k][j];
                                }
				M3[i][j] = temp;
                        }
                }
        return 0;
}


float a[LEN] __attribute__ ((aligned(16)));
float b[LEN] __attribute__ ((aligned(16)));

int s119()
{

                for (int i = 4; i < LEN; i++) {
                        a[i] = a[i-4] + b[i];
                }
        return 0;
}

void unknown_alignment(float* __restrict__ A, float* __restrict__ B, float* __restrict__ C){
  for (int i = 0; i < 1024; i++){
    A[i] = B[i] + C[i];
  }
}
